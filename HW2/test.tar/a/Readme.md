<h1> Homework Assignment #2 </h1>
<h2> Program description </h2>
    <p>This assignment requires that you write a program in C++ to list the contents of a TAR file. The format of TAR
    files can be found at <a href = "http://en.wikipedia.org/wiki/Tar">wikipidia </a>.
    </p>
<h2>Build </h2>
    <ol>
        <li> <code>make</code> </li>
        <li> <code>./mytar test.tar</code> to show tar's content </li>
        <li> <code>make clean</code> </li>
    </ol>
